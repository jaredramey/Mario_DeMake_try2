Controls:
-----------
W - Interact with object
A - Move left
D - Move Right
Space - Jump